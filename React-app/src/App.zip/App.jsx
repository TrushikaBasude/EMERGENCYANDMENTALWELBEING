import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./Components/Home";
import { SignUp } from "./Components/SignUp";
import { Login } from "./Components/Login"; // Use curly braces for named export

import Help from "./Components/sosemergency";
import Assessment from "./Components/assessment";
import Chatbot from "./Components/Chatbot";
import Videorecommend from "./Components/Videorecommend"; // Fixed component name
import "./App.css";

function App() {
  return (
    <Router>
      <div className="main_section">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/login" element={<Login />} />
          <Route path="/sos" element={<Help />} />
          <Route path="/assessment" element={<Assessment />} />
          <Route path="/chatbot" element={<Chatbot />} />
          <Route path="/videos" element={<Videorecommend />} /> {/* Fixed */}
        </Routes>
      </div>
    </Router>
  );
}

export default App;
