import React from 'react'
import { useState } from 'react'
import '../Components/SignUp.css'
import Form from 'react-bootstrap/Form'
import { useNavigate } from 'react-router-dom'

export const SignUp = () => {

  const navigate = useNavigate(); 

  const [error, setError] = useState(false); 
  const handleValues = () =>{
    
  }

  const[data, setData] = useState (
    {
       fname: "",
       lname:"",
       email: "",
       password: ""
    }
  );
    const handleChange = (event) => {
      const { name, value } = event.target;
      setData({
          ...data, [name]:value
      });
    }
    const handleSubmit = async (event) => {
      event.preventDefault();
      const { fname, lname, email, password } = data; 
      if (!fname || !lname || !email || !password) {
        setError(true);
      }
      else {
          setError(false);
          console.log("Email:", email, "Password:", password);
          setTimeout(()=>{
            alert("Registration SucessFull Redirecting To Login...!");
            navigate("/login");
         },1000);
      }
    }

  return ( 


          <div className="SignUp_section" >
            <Form onSubmit={handleSubmit}>
              <h2>Create Your Account</h2>
              <label htmlFor="fname">First Name</label>
              <input type="text" name='fname' value={data.fname} onChange={handleChange} required/>
              <label htmlFor="lname">Last Name</label>
              <input type="text" name='lname' value={data.lname} onChange={handleChange} required/>
              <label htmlFor="email">Email</label>
              <input type="email" name='email' value={data.email} onChange={handleChange} required/>
              <label htmlFor="password">Password</label>
              <input type="password" name='password' value={data.password} onChange={handleChange} required/>
              <button type="submit" >Register</button>
            </Form>
            {error && <p>Registration SuccesFull..!</p>}
          </div>

  )
}
