import React, { useState } from "react";
import "../Components/Chatbot.css";

const Chatbot = () => {
    const [messages, setMessages] = useState([]);
    const [input, setInput] = useState("");

    const getBotResponse = (userMessage) => {
        const lowerMessage = userMessage.toLowerCase();

        if (lowerMessage.includes("stress")) {
            return (
                <> 
                    Stress can be managed by practicing deep breathing, meditation, regular exercise, and maintaining a healthy sleep schedule. Talking to a trusted friend or professional can also help.<br />
                    <br /> Identify the Cause – Understand what’s triggering your stress and work on solutions.
                    <br /> Practice Deep Breathing – Try slow, deep breaths to calm your mind.
                    <br /> Exercise Regularly – Physical activity helps reduce stress hormones.
                    <br /> Take Breaks – Short breaks can refresh your mind.
                    Learn more: <a href="https://www.healthline.com/nutrition/16-ways-relieve-stress" target="_blank" rel="noopener noreferrer">Stress Management</a>
                </>
            );
        } else if (lowerMessage.includes("suicidal")) {
            return (
                <> 
                    I'm really sorry you're feeling this way. You are not alone, and support is available. Please consider reaching out to a mental health professional or a trusted person in your life. <br />
                    <br /> Talk to someone you trust – A friend, family member, or mentor can provide support.
                    <br /> Reach out to a professional – A therapist or counselor can help you navigate your feelings.
                    <br /> Call a helpline – Many countries have 24/7 crisis helplines where trained professionals can support you.
                    Get Help: <a href="https://findahelpline.com/" target="_blank" rel="noopener noreferrer">Find a Helpline</a>
                </>
            );
        } else if (lowerMessage.includes("improve sleep")) {
            return (
                <> 
                    <br /> Stick to a consistent sleep schedule.
                    <br /> Avoid screens 30–60 minutes before bed.
                    <br /> Limit caffeine and heavy meals in the evening.
                    <br /> Create a relaxing bedtime routine like reading or meditation.
                    <br /> Keep your room dark, cool, and quiet.
                    <br /> Exercise regularly but not too close to bedtime.
                    More tips: <a href="https://www.sleepfoundation.org/sleep-hygiene" target="_blank" rel="noopener noreferrer">Better Sleep Guide</a>
                </>
            );
        } else if (lowerMessage.includes("focus better")) {
            return (
                <> 
                    To improve focus, try minimizing distractions, practicing mindfulness, and taking regular breaks.<br />
                    <br /> Eliminate Distractions – Silence notifications, use focus mode, and keep your workspace clutter-free.
                    <br /> Use the Pomodoro Technique – Work for 25-50 minutes, then take a 5-10 minute break.
                    <br /> Train Your Brain – Try puzzles, meditation, or deep reading to strengthen focus.
                    <br /> Stay Hydrated & Eat Brain Food – Drink water and eat nuts, dark chocolate, and berries for better concentration.
                    <br /> Get Enough Sleep – Aim for 7-8 hours of rest to improve cognitive function.
                    <br /> Exercise Regularly – Even a short walk boosts blood flow to the brain.
                    Learn more: <a href="https://www.verywellmind.com/how-to-improve-your-focus-2795009" target="_blank" rel="noopener noreferrer">Improve Focus</a>
                </>
            );
        } else if (lowerMessage.includes("happy") && lowerMessage.includes("healthy")) {
            return (
                <> 
                    Living a happy and healthy life involves maintaining a positive mindset, a balanced diet, and regular exercise.<br />
                    <br /> Practice Gratitude – Focus on positive aspects of life daily.
                    <br /> Eat Nutritious Foods – Include fruits, vegetables, and proteins in your diet.
                    <br /> Stay Active – Engage in physical activity to boost mood and health.
                    <br /> Connect with Others – Build meaningful relationships with friends and family.
                    <br /> Manage Stress – Try meditation, journaling, or talking to someone.
                </>
            );
        } else if (lowerMessage.includes("distraction")) {
            return (
                <> 
                    To avoid distractions, create a focused environment and use productivity techniques.<br />
                    <br /> Remove Unnecessary Noise – Use noise-canceling headphones or a quiet workspace.
                    <br /> Set Clear Goals – Break tasks into small, manageable steps.
                    <br /> Use Time Management Techniques – Try the Pomodoro technique for focused work sessions.
                    <br /> Limit Social Media – Use website blockers to stay on track.
                    <br /> Prioritize Tasks – Focus on the most important work first.
                </>
            );
        } else if (lowerMessage.includes("socialize")) {
            return (
                <> 
                    Socializing can help improve mood and well-being. Here’s how you can start:<br />
                    <br /> Join Groups or Clubs – Engage in activities that interest you.
                    <br /> Start Small – Begin with casual conversations and small gatherings.
                    <br /> Be Open to New Connections – Approach people with a friendly attitude.
                    <br /> Improve Communication Skills – Practice active listening and asking questions.
                    <br /> Stay in Touch – Keep in contact with old and new friends.
                </>
            );
        } else if (lowerMessage.includes("lonely")) {
            return (
                <> 
                    Feeling lonely can be difficult, but there are ways to feel more connected.<br />
                    <br /> Reach Out to Friends & Family – Call or text someone you trust.
                    <br /> Engage in Activities – Hobbies, volunteering, or joining groups can help you meet people.
                    <br /> Practice Self-Care – Take care of yourself physically and mentally.
                    <br /> Seek Support – A therapist or support group can help if loneliness persists.
                </>
            );
        } else {
            return "Hi there! I'm here to listen. Could you tell me more about how I can help you?";
        }
    };

    const handleSendMessage = () => {
        if (input.trim() === "") return;

        const userMessage = { text: input, sender: "user" };
        setMessages([...messages, userMessage]);

        setTimeout(() => {
            const botReply = { text: getBotResponse(input), sender: "bot" };
            setMessages((prev) => [...prev, botReply]);
        }, 1000);

        setInput("");
    };

    return (
        <div className="chatbot-container">
            <div className="chatbot-header">Chat with AI</div>
            <div className="chatbox">
                {messages.map((msg, index) => (
                    <div key={index} className={`message ${msg.sender}`}>
                        {msg.text}
                    </div>
                ))}
            </div>
            <div className="input-area">
                <input type="text" value={input} onChange={(e) => setInput(e.target.value)} placeholder="Ask me anything..." />
                <button onClick={handleSendMessage}>Send</button>
            </div>
        </div>
    );
};

export default Chatbot;
