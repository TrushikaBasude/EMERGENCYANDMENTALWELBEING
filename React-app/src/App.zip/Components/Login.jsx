import { React,useState } from 'react'
import '../Components/Login.css'
import { useNavigate,Link } from 'react-router-dom'
import Form from 'react-bootstrap/Form'

export const Login = () => {

  const navigate=useNavigate();

  const [error, setError] = useState(false); 

  const [logindata,setLogindata] =useState(
    {
      email:"",
      password:""
    }
  );

  const { email, password } = logindata;

  const handleChange = (e) =>{
    const{ name,value }=e.target;
    setLogindata({
      ...logindata, [name]:value
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email || !password) {
      setError(true);
    } else {
        setError(false);
        console.log("Email:", email, "Password:", password);
        setTimeout(()=>{
          alert("Login Successfull...!");
          navigate("/");
      },1000);
  
    }
  }

  return (
    
        <div className="Login_section" >
            <h2>Welcome Back</h2>
            <Form onSubmit={handleSubmit}>
              <label>Email</label>
              <input type="email" name='email' value={logindata.email} onChange={handleChange} required></input>
              <label>Password</label>
              <input type="password" name='password' value={logindata.password} onChange={handleChange} required></input>
              <button type="submit" >Log In</button>
            </Form>
            <div className="Login_option">
                <a href='/forgetpasswordpage'>Forgot password? </a>  <span>|</span>  <a href='/signup'>Create an account</a>
            </div>
            
        </div>
        
  )
}